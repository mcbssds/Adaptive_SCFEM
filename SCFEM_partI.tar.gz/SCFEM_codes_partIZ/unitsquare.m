%UNITSQUARE outlines square domain (0,1)^2
%   TIFISS scriptfile: LR; 22 June 2018
% Copyright (c) 2018 A. Bespalov, L. Rocchi

  hold on
  plot([0 1], [0,0],'-k');
  plot([1,1], [0,1],'-k');
  plot([1,0], [1,1],'-k');
  plot([0,0], [1,0],'-k');
  hold off

% end scriptfile